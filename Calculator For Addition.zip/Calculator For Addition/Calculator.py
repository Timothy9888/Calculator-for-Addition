a=int(input('Write the first number here:'))
b=int(input('Write the second number here:'))
print(a,'+',b,'is','=',a+b)
